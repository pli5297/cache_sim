var searchData=
[
  ['update_5flru_35',['update_LRU',['../namespacecachesimulator.html#a4a450a4505019d63b1a34701272b8cdc',1,'cachesimulator']]],
  ['user_5fprompt_36',['user_prompt',['../namespacecachesimulator.html#a1ec5f8490e9cbb3a62bbae485f2d4733',1,'cachesimulator']]]
];
