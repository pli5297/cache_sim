var searchData=
[
  ['cache_70',['CACHE',['../namespacecachesimulator.html#a699364cc9498add239917c0caeb2e030',1,'cachesimulator']]],
  ['cache_5fhits_71',['cache_hits',['../namespacecachesimulator.html#af04ad8b4ec6b6fc50aca3a4b07779b43',1,'cachesimulator']]],
  ['cache_5flru_5finfo_72',['cache_lru_info',['../namespacecachesimulator.html#a8ad91b560c94626db18cdf03c172d8b2',1,'cachesimulator']]],
  ['cache_5fmisses_73',['cache_misses',['../namespacecachesimulator.html#ac35720af499fdb5857f08620d8052929',1,'cachesimulator']]],
  ['cache_5fsize_74',['cache_size',['../namespacecachesimulator.html#a3b7dabbe2938c182f1254c1f807570dc',1,'cachesimulator']]]
];
