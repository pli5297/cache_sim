var searchData=
[
  ['wh_5fpol_37',['wh_pol',['../namespacecachesimulator.html#acebc365ba3d6145e297698a4a4659222',1,'cachesimulator']]],
  ['wm_5fpol_38',['wm_pol',['../namespacecachesimulator.html#a60d9c80d31ac595c00ed6050cfa0fa21',1,'cachesimulator']]],
  ['write_5fblock_5fto_5fram_39',['write_block_to_ram',['../namespacecachesimulator.html#ae976747ae597bc842b4bf06f9ae60240',1,'cachesimulator']]],
  ['write_5fto_5fcache_40',['write_to_cache',['../namespacecachesimulator.html#a1a16d6771502380c17f4515e22899120',1,'cachesimulator']]],
  ['write_5fto_5fram_41',['write_to_ram',['../namespacecachesimulator.html#a88ee2a35cd67e0d395b056f1cddc90a2',1,'cachesimulator']]]
];
