var searchData=
[
  ['find_5fcache_57',['find_cache',['../namespacecachesimulator.html#a5cc46f4ccd8a89051f62548e53dd46b9',1,'cachesimulator']]],
  ['find_5fram_58',['find_ram',['../namespacecachesimulator.html#aaa716c949d4b975ecbb60becedc320b3',1,'cachesimulator']]]
];
