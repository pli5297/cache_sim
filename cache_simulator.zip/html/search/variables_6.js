var searchData=
[
  ['tag_5fbits_82',['tag_bits',['../namespacecachesimulator.html#aed0e6ab2d7b5f23d0339f7c07f521cb9',1,'cachesimulator']]]
];
