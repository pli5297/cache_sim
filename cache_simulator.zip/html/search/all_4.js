var searchData=
[
  ['index_5fbits_20',['index_bits',['../namespacecachesimulator.html#a1cb2ea42ea264fbf364e74475cba9c34',1,'cachesimulator']]],
  ['init_5fphys_5fmem_21',['init_phys_mem',['../namespacecachesimulator.html#ab184ba2b72a17775faa66630b1d995f2',1,'cachesimulator']]],
  ['input_2etxt_22',['input.txt',['../input_8txt.html',1,'']]]
];
