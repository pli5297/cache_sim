var searchData=
[
  ['n_5fway_27',['n_way',['../namespacecachesimulator.html#a42df79159d9f1a9fc917688e497edfe7',1,'cachesimulator']]],
  ['num_5fsets_28',['num_sets',['../namespacecachesimulator.html#a56c222e324f84e496c92e5b2c60d23e0',1,'cachesimulator']]]
];
