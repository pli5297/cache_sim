var searchData=
[
  ['init_5fphys_5fmem_59',['init_phys_mem',['../namespacecachesimulator.html#ab184ba2b72a17775faa66630b1d995f2',1,'cachesimulator']]]
];
