var searchData=
[
  ['located_76',['located',['../README_8txt.html#ae9733f0fbe15f5192bd479ba68995a01',1,'README.txt']]]
];
