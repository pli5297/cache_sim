var searchData=
[
  ['index_5fbits_75',['index_bits',['../namespacecachesimulator.html#a1cb2ea42ea264fbf364e74475cba9c34',1,'cachesimulator']]]
];
