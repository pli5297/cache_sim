var searchData=
[
  ['write_5fblock_5fto_5fram_65',['write_block_to_ram',['../namespacecachesimulator.html#ae976747ae597bc842b4bf06f9ae60240',1,'cachesimulator']]],
  ['write_5fto_5fcache_66',['write_to_cache',['../namespacecachesimulator.html#a1a16d6771502380c17f4515e22899120',1,'cachesimulator']]],
  ['write_5fto_5fram_67',['write_to_ram',['../namespacecachesimulator.html#a88ee2a35cd67e0d395b056f1cddc90a2',1,'cachesimulator']]]
];
