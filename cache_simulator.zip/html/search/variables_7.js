var searchData=
[
  ['wh_5fpol_83',['wh_pol',['../namespacecachesimulator.html#acebc365ba3d6145e297698a4a4659222',1,'cachesimulator']]],
  ['wm_5fpol_84',['wm_pol',['../namespacecachesimulator.html#a60d9c80d31ac595c00ed6050cfa0fa21',1,'cachesimulator']]]
];
