var searchData=
[
  ['add_5fcache_0',['add_cache',['../namespacecachesimulator.html#a4e6973db01a3ee1687d46d3873751eb5',1,'cachesimulator']]]
];
