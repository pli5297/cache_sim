var searchData=
[
  ['block_5fbits_68',['block_bits',['../namespacecachesimulator.html#a23f384c227511d05a0ffee796f08685d',1,'cachesimulator']]],
  ['block_5fsize_69',['block_size',['../namespacecachesimulator.html#a1ec1b56d067d313571f18f17c15992ef',1,'cachesimulator']]]
];
